package com.cts.api.controller;

import java.util.Date;
import javax.xml.bind.JAXBException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;
import com.cts.bo.Employee;
import com.cts.bo.ErrorLog;
import com.cts.main.dao.EmployeeDao;
import com.cts.main.dao.ErrorLoggerDao;
import com.cts.util.ValidatorUtil;

@RestController
public class EmployeeController {
	
	Logger logger = Logger.getLogger(EmployeeController.class);

	@Autowired
	EmployeeDao empDao;
	
	@Autowired
	ErrorLoggerDao erroLoggerDao;
	
		
    @PostMapping(path = "/saveUpdateEmpData", consumes=MediaType.APPLICATION_XML_VALUE)
    public String customerInformation(@RequestBody Employee emp) {
    	logger.info("Request received in controller");
    	ErrorLog errorLog = new ErrorLog();
    	//Validate input xml against XSD
    	try {
    	ValidatorUtil.validateRequest(emp);
    	
    	}catch (JAXBException |SAXException e) {
    		//Log validation Errors
    		errorLog.setErrorCode(100);
    		errorLog.setErrorType("Validation");
    		errorLog.setErrorDesc("Invalid request format");
    		errorLog.setErrorCreated(new java.sql.Date(new Date().getTime()));
    		erroLoggerDao.logError(errorLog);
    		e.printStackTrace();
    		return "Invalid request";
		}catch (Exception e) {
			logger.info("Generic Exception");
			errorLog.setErrorCode(200);
    		errorLog.setErrorType("Generic Exception");
    		errorLog.setErrorDesc("Gneric Exception "+e.getMessage());
    		errorLog.setErrorCreated(new java.sql.Date(new Date().getTime()));
    		erroLoggerDao.logError(errorLog);    		
			return null;
		}
    	
    	//Verify if employee is already in System
    	if(empDao.findEmployeeById(emp.getId())==null) {
    	empDao.save(emp);
    	 return "Customer information Saved successfully " + emp.getId()+" "+emp.getName();
    	}else {
    		//Update record when employee is already in system
    		empDao.update(emp);
    		 return "Customer information Updated successfully " + emp.getId()+" "+emp.getName();
    	}
    	
    	
    }
}
