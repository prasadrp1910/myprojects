package com.cts.bo;

import java.sql.Date;

public class ErrorLog {

	private int errorCode;
	private String errorType;
	private String errorDesc;
	private Date errorCreated;
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorType() {
		return errorType;
	}
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public Date getErrorCreated() {
		return errorCreated;
	}
	public void setErrorCreated(Date errorCreated) {
		this.errorCreated = errorCreated;
	}
	
	
	
}
