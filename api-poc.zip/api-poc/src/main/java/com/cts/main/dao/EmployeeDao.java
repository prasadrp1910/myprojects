package com.cts.main.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bo.Employee;

@Repository
@Transactional
public class EmployeeDao {
	
	Logger log = Logger.getLogger(EmployeeDao.class);
	
	final String INSERT_SQL = "insert into EMPLOYEE (id, name, department) values (?, ?, ?)";
	final String UPDATE_SQL = "update EMPLOYEE set name = ? , department= ? where id = ?";
	final String SELECT_SQL = "select name from EMPLOYEE where id = ?";
	
	
	@Autowired
	  private JdbcTemplate jdbcTemplate;

	  public void save(Employee employee) {
		  log.info("Saving Employee Details");
	     jdbcTemplate.update(INSERT_SQL, employee.getId(),employee.getName(),employee.getDepartment());
	  }
	  
 public void update(Employee employee) {		  
	 log.info("Updating Employee Details");
	      jdbcTemplate.update(UPDATE_SQL, employee.getName(),employee.getDepartment(),employee.getId());
	  }
 
 @SuppressWarnings("unchecked")
 public String  findEmployeeById(int id) {
	 
	 jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS EMPLOYEE (id int, name varchar,department varchar)");
	 String sql = "SELECT NAME FROM EMPLOYEE WHERE ID = ?";
	 
	List<String> strLst  = jdbcTemplate.query(sql,new RowMapper() {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			 return rs.getString(1);
	}},id);
	if ( strLst.isEmpty() ){
		  return null;
		}else if ( strLst.size() == 1 ) {
		  return strLst.get(0);
		}
		return null;     
 }
	  
	  

}
